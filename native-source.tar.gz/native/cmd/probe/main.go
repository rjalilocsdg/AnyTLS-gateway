// Interoperability probe using the official AnyTLS client session engine.
package main

import (
	"anytls/proxy/padding"
	"anytls/proxy/session"
	"bytes"
	"crypto/sha256"
	"crypto/tls"
	"crypto/x509"
	"encoding/binary"
	"flag"
	"fmt"
	"io"
	"net"
	"os"
	"sync"
	"time"

	M "github.com/sagernet/sing/common/metadata"
	"github.com/sagernet/sing/common/uot"
)

func run() error {
	address := flag.String("server", "localhost:8443", "TLS server")
	password := flag.String("password", "", "AnyTLS password")
	ca := flag.String("ca", "", "trusted certificate")
	target := flag.String("target", "", "echo server")
	mode := flag.String("mode", "tcp", "tcp or udp")
	size := flag.Int("size", 65536, "payload size")
	streams := flag.Int("streams", 2, "concurrent TCP streams")
	fragment := flag.Bool("fragment", false, "fragment the authentication header")
	watchClose := flag.Bool("watch-close", false, "wait for policy revocation of an active stream")
	flag.Parse()
	cert, err := os.ReadFile(*ca)
	if err != nil {
		return err
	}
	roots := x509.NewCertPool()
	if !roots.AppendCertsFromPEM(cert) {
		return fmt.Errorf("invalid CA file")
	}
	host, _, err := net.SplitHostPort(*address)
	if err != nil {
		return err
	}
	raw, err := tls.DialWithDialer(&net.Dialer{Timeout: 5 * time.Second}, "tcp", *address, &tls.Config{RootCAs: roots, ServerName: host, MinVersion: tls.VersionTLS12})
	if err != nil {
		return err
	}
	defer raw.Close()
	raw.SetDeadline(time.Now().Add(15 * time.Second))
	hash := sha256.Sum256([]byte(*password))
	authentication := make([]byte, 64)
	copy(authentication, hash[:])
	binary.BigEndian.PutUint16(authentication[32:34], 30)
	if *fragment {
		for _, b := range authentication {
			if _, err = raw.Write([]byte{b}); err != nil {
				return err
			}
		}
	} else if _, err = raw.Write(authentication); err != nil {
		return err
	}
	sess := session.NewClientSession(raw, &padding.DefaultPaddingFactory)
	sess.Run()
	defer sess.Close()
	destination := M.ParseSocksaddr(*target)
	if *mode == "udp" {
		conn, err := sess.OpenStream()
		if err != nil {
			return err
		}
		defer conn.Close()
		if err = M.SocksaddrSerializer.WriteAddrPort(conn, uot.RequestDestination(2)); err != nil {
			return err
		}
		request := uot.Request{IsConnect: true, Destination: destination}
		if err = uot.WriteRequest(conn, request); err != nil {
			return err
		}
		packet := uot.NewConn(conn, request)
		payload := bytes.Repeat([]byte("u"), min(*size, 65000))
		if _, err = packet.Write(payload); err != nil {
			return err
		}
		result := make([]byte, 65536)
		n, err := packet.Read(result)
		if err != nil {
			return err
		}
		if !bytes.Equal(result[:n], payload) {
			return fmt.Errorf("UDP payload mismatch")
		}
		fmt.Println("UDP echo verified")
		return nil
	}
	var conns []net.Conn
	for i := 0; i < *streams; i++ {
		c, err := sess.OpenStream()
		if err != nil {
			return err
		}
		if err = M.SocksaddrSerializer.WriteAddrPort(c, destination); err != nil {
			return err
		}
		conns = append(conns, c)
		defer c.Close()
	}
	var wg sync.WaitGroup
	results := make(chan error, len(conns))
	for i, conn := range conns {
		wg.Add(1)
		go func(index int, c net.Conn) {
			defer wg.Done()
			payload := bytes.Repeat([]byte{byte('a' + index)}, *size)
			written := make(chan error, 1)
			go func() {
				for offset := 0; offset < len(payload); offset += 16384 {
					if _, err := c.Write(payload[offset:min(offset+16384, len(payload))]); err != nil {
						written <- err
						return
					}
				}
				written <- nil
			}()
			received := make([]byte, len(payload))
			if _, err := io.ReadFull(c, received); err != nil {
				results <- err
				return
			}
			if !bytes.Equal(received, payload) {
				results <- fmt.Errorf("TCP payload mismatch")
				return
			}
			if err := <-written; err != nil {
				results <- err
				return
			}
			results <- nil
		}(i, conn)
	}
	wg.Wait()
	close(results)
	for err := range results {
		if err != nil {
			return err
		}
	}
	fmt.Printf("TCP echo verified: %d streams, %d bytes each\n", len(conns), *size)
	if *watchClose {
		conns[0].SetReadDeadline(time.Now().Add(5 * time.Second))
		_, err := conns[0].Read(make([]byte, 1))
		if err == nil {
			return fmt.Errorf("unexpected data while waiting for revocation")
		}
		if timeout, ok := err.(net.Error); ok && timeout.Timeout() {
			return fmt.Errorf("revoked stream did not close: %w", err)
		}
		fmt.Println("Active stream revocation verified")
	}
	return nil
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
