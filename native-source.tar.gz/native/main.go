package main

import (
	"anytls/proxy/padding"
	"anytls/proxy/session"
	"context"
	"crypto/ecdsa"
	"crypto/elliptic"
	"crypto/rand"
	"crypto/tls"
	"crypto/x509"
	"crypto/x509/pkix"
	"encoding/binary"
	"encoding/hex"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"log"
	"math/big"
	"net"
	"os"
	"path/filepath"
	"sync"
	"time"

	"github.com/sagernet/sing/common/bufio"
	M "github.com/sagernet/sing/common/metadata"
	"github.com/sagernet/sing/common/uot"
)

func env(key, fallback string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return fallback
}

type reply struct {
	OK    bool   `json:"ok"`
	UUID  string `json:"uuid"`
	Error string `json:"error"`
}

type control struct {
	net.Conn
	encoder *json.Encoder
	decoder *json.Decoder
	mu      sync.Mutex
}

func newControl() (*control, error) {
	c, err := net.DialTimeout("unix", env("ANYTLS_CONTROL_SOCKET", "/tmp/anytls-gateway.sock"), 5*time.Second)
	if err != nil {
		return nil, err
	}
	return &control{Conn: c, encoder: json.NewEncoder(c), decoder: json.NewDecoder(c)}, nil
}

func (c *control) call(request map[string]any) (reply, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	c.SetDeadline(time.Now().Add(60 * time.Second))
	var response reply
	if err := c.encoder.Encode(request); err != nil {
		return response, err
	}
	if err := c.decoder.Decode(&response); err != nil {
		return response, err
	}
	if !response.OK {
		return response, errors.New(response.Error)
	}
	return response, nil
}

type managedConn struct {
	net.Conn
	control *control
	once    sync.Once
	done    chan struct{}
}

func manage(stream net.Conn, uid, ip, target string) (*managedConn, error) {
	c, err := newControl()
	if err != nil {
		return nil, err
	}
	if _, err = c.call(map[string]any{"op": "open", "uuid": uid, "ip": ip, "target": target}); err != nil {
		c.Close()
		return nil, err
	}
	m := &managedConn{Conn: stream, control: c, done: make(chan struct{})}
	go func() {
		ticker := time.NewTicker(2 * time.Second)
		defer ticker.Stop()
		for {
			select {
			case <-m.done:
				return
			case <-ticker.C:
				if _, err := c.call(map[string]any{"op": "status"}); err != nil {
					m.Close()
					return
				}
			}
		}
	}()
	return m, nil
}

func (m *managedConn) Read(buffer []byte) (int, error) {
	if len(buffer) > 16384 {
		buffer = buffer[:16384]
	}
	n, err := m.Conn.Read(buffer)
	if n > 0 {
		if _, chargeErr := m.control.call(map[string]any{"op": "charge", "bytes": n}); chargeErr != nil {
			m.Close()
			return 0, chargeErr
		}
	}
	return n, err
}

func (m *managedConn) Write(buffer []byte) (int, error) {
	total := 0
	for len(buffer) > 0 {
		chunk := buffer[:min(len(buffer), 16384)]
		if _, err := m.control.call(map[string]any{"op": "charge", "bytes": len(chunk)}); err != nil {
			m.Close()
			return total, err
		}
		n, err := m.Conn.Write(chunk)
		total += n
		buffer = buffer[n:]
		if err != nil {
			return total, err
		}
		if n == 0 {
			return total, io.ErrShortWrite
		}
	}
	return total, nil
}

func (m *managedConn) Close() error {
	m.once.Do(func() {
		close(m.done)
		m.control.Close()
		m.Conn.Close()
	})
	return nil
}

func serveStream(stream *session.Stream, uid, ip string) {
	defer func() {
		if recovered := recover(); recovered != nil {
			log.Printf("stream panic: %v", recovered)
		}
	}()
	defer stream.Close()
	stream.SetReadDeadline(time.Now().Add(15 * time.Second))
	destination, err := M.SocksaddrSerializer.ReadAddrPort(stream)
	if err != nil {
		stream.HandshakeFailure(err)
		return
	}
	stream.SetReadDeadline(time.Time{})
	conn, err := manage(stream, uid, ip, destination.String())
	if err != nil {
		stream.HandshakeFailure(err)
		return
	}
	defer conn.Close()
	if destination.Fqdn == uot.MagicAddress || destination.Fqdn == uot.LegacyMagicAddress {
		// The upstream engine and sing library provide AnyTLS UDP-over-TCP.
		var request *uot.Request
		if destination.Fqdn == uot.MagicAddress {
			request, err = uot.ReadRequest(conn)
			if err != nil {
				stream.HandshakeFailure(err)
				return
			}
		} else {
			request = &uot.Request{}
		}
		packet, err := net.ListenPacket("udp", "")
		if err != nil {
			stream.HandshakeFailure(err)
			return
		}
		defer packet.Close()
		if err = stream.HandshakeSuccess(); err != nil {
			return
		}
		ctx, cancel := context.WithCancel(context.Background())
		defer cancel()
		go func() {
			select {
			case <-conn.done:
				cancel()
				packet.Close()
			case <-ctx.Done():
			}
		}()
		bufio.CopyPacketConn(ctx, uot.NewConn(conn, *request), bufio.NewPacketConn(packet))
		return
	}
	outbound, err := net.DialTimeout("tcp", destination.String(), 10*time.Second)
	if err != nil {
		stream.HandshakeFailure(err)
		return
	}
	defer outbound.Close()
	if err = stream.HandshakeSuccess(); err != nil {
		return
	}
	done := make(chan struct{}, 2)
	go func() { io.CopyBuffer(outbound, conn, make([]byte, 16384)); done <- struct{}{} }()
	go func() { io.CopyBuffer(conn, outbound, make([]byte, 16384)); done <- struct{}{} }()
	<-done
	outbound.Close()
	conn.Close()
	<-done
}

func serve(raw net.Conn, config *tls.Config) {
	defer raw.Close()
	defer func() {
		if recovered := recover(); recovered != nil {
			log.Printf("session panic: %v", recovered)
		}
	}()
	conn := tls.Server(raw, config)
	conn.SetDeadline(time.Now().Add(15 * time.Second))
	// ReadFull preserves authentication and settings across TCP fragmentation.
	header := make([]byte, 34)
	if _, err := io.ReadFull(conn, header); err != nil {
		return
	}
	auth, err := newControl()
	if err != nil {
		return
	}
	result, err := auth.call(map[string]any{"op": "auth", "hash": hex.EncodeToString(header[:32])})
	auth.Close()
	if err != nil || result.UUID == "" {
		return
	}
	if _, err = io.CopyN(io.Discard, conn, int64(binary.BigEndian.Uint16(header[32:]))); err != nil {
		return
	}
	conn.SetDeadline(time.Time{})
	ip, _, _ := net.SplitHostPort(raw.RemoteAddr().String())
	s := session.NewServerSession(conn, func(stream *session.Stream) { serveStream(stream, result.UUID, ip) }, &padding.DefaultPaddingFactory)
	defer s.Close()
	s.Run()
}

func certificate() (tls.Certificate, error) {
	host := env("ANYTLS_SNI", env("ANYTLS_PUBLIC_HOST", env("RAILWAY_TCP_PROXY_DOMAIN", "localhost")))
	certPath, keyPath := os.Getenv("ANYTLS_TLS_CERT"), os.Getenv("ANYTLS_TLS_KEY")
	if certPath != "" || keyPath != "" {
		if certPath == "" || keyPath == "" {
			return tls.Certificate{}, errors.New("set both ANYTLS_TLS_CERT and ANYTLS_TLS_KEY")
		}
		return tls.LoadX509KeyPair(certPath, keyPath)
	}
	directory := env("DATA_DIR", "/data")
	if err := os.MkdirAll(directory, 0700); err != nil {
		return tls.Certificate{}, err
	}
	certPath, keyPath = filepath.Join(directory, "anytls.crt"), filepath.Join(directory, "anytls.key")
	if cert, err := tls.LoadX509KeyPair(certPath, keyPath); err == nil {
		leaf, err := x509.ParseCertificate(cert.Certificate[0])
		if err == nil && time.Now().Add(24*time.Hour).Before(leaf.NotAfter) && leaf.VerifyHostname(host) == nil {
			return cert, nil
		}
	}
	key, err := ecdsa.GenerateKey(elliptic.P256(), rand.Reader)
	if err != nil {
		return tls.Certificate{}, err
	}
	serial, err := rand.Int(rand.Reader, new(big.Int).Lsh(big.NewInt(1), 128))
	if err != nil {
		return tls.Certificate{}, err
	}
	template := x509.Certificate{SerialNumber: serial, Subject: pkix.Name{CommonName: host}, NotBefore: time.Now().Add(-time.Hour), NotAfter: time.Now().AddDate(1, 0, 0), KeyUsage: x509.KeyUsageDigitalSignature, ExtKeyUsage: []x509.ExtKeyUsage{x509.ExtKeyUsageServerAuth}}
	if ip := net.ParseIP(host); ip != nil {
		template.IPAddresses = []net.IP{ip}
	} else {
		template.DNSNames = []string{host}
	}
	der, err := x509.CreateCertificate(rand.Reader, &template, &template, &key.PublicKey, key)
	if err != nil {
		return tls.Certificate{}, err
	}
	keyBytes, err := x509.MarshalPKCS8PrivateKey(key)
	if err != nil {
		return tls.Certificate{}, err
	}
	certPEM := pem.EncodeToMemory(&pem.Block{Type: "CERTIFICATE", Bytes: der})
	keyPEM := pem.EncodeToMemory(&pem.Block{Type: "PRIVATE KEY", Bytes: keyBytes})
	if err = os.WriteFile(keyPath, keyPEM, 0600); err != nil {
		return tls.Certificate{}, err
	}
	if err = os.WriteFile(certPath, certPEM, 0644); err != nil {
		return tls.Certificate{}, err
	}
	log.Print("Generated persistent self-signed TLS certificate; configure ANYTLS_TLS_CERT/KEY for verified TLS")
	return tls.X509KeyPair(certPEM, keyPEM)
}

func main() {
	cert, err := certificate()
	if err != nil {
		log.Fatal(err)
	}
	if path := os.Getenv("ANYTLS_PADDING_SCHEME"); path != "" {
		raw, err := os.ReadFile(path)
		if err != nil || !padding.UpdatePaddingScheme(raw) {
			log.Fatal("invalid padding scheme file")
		}
	}
	config := &tls.Config{Certificates: []tls.Certificate{cert}, MinVersion: tls.VersionTLS12}
	listener, err := net.Listen("tcp", ":"+env("ANYTLS_PORT", "8443"))
	if err != nil {
		log.Fatal(err)
	}
	log.Print("AnyTLS raw TLS listener ready: ", listener.Addr())
	for {
		conn, err := listener.Accept()
		if err != nil {
			log.Fatal(fmt.Errorf("accept: %w", err))
		}
		go serve(conn, config)
	}
}
